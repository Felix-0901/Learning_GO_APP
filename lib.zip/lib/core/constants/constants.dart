/// 匯出核心常數
library;

export 'app_colors.dart';
